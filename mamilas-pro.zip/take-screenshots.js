const puppeteer = require('puppeteer');
const { spawn } = require('child_process');

(async () => {
  console.log("Starting server...");
  const server = spawn('node', ['server.js'], { env: { ...process.env, PORT: 3000 } });
  
  // Wait a bit for server to start
  await new Promise(r => setTimeout(r, 2000));
  
  console.log("Launching browser...");
  const browser = await puppeteer.launch({ headless: 'new' });
  const page = await browser.newPage();
  
  console.log("Navigating to local site (port 3000)...");
  
  try {
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle0', timeout: 10000 });
    
    // Evaluate some interactions if needed? No just capture initial layout
    
    console.log("Capturing Desktop...");
    await page.setViewport({width: 1440, height: 900});
    await page.screenshot({path: 'desktop.png', fullPage: true});
    
    console.log("Capturing Mobile...");
    await page.setViewport({width: 390, height: 844});
    await page.screenshot({path: 'mobile.png', fullPage: true});
    
    console.log("Screenshots saved.");
  } catch (e) {
    console.error("Puppeteer Error:", e);
  } finally {
    await browser.close();
    server.kill();
    process.exit(0);
  }
})();
